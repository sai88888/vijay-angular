import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sortedheader',
  templateUrl: './sortedheader.component.html',
  styleUrls: ['./sortedheader.component.css']
})
export class SortedheaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SortedheaderComponent } from './sortedheader.component';

describe('SortedheaderComponent', () => {
  let component: SortedheaderComponent;
  let fixture: ComponentFixture<SortedheaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SortedheaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SortedheaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component } from '@angular/core';
import { Employee } from './employee';
import { EmployeeService } from './employee.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'LabBook';

  service:EmployeeService=new EmployeeService();
  
  emparr:Employee[]=[];

  addemp(data) {
    this.emparr=this.service.addemployee(data);
  }

  uid:number;uname:string;usalary:number;udepartment:string;
  updating(emp) {
    this.uid=emp.id;
    this.uname=emp.name;
    this.usalary=emp.salary;
    this.udepartment=emp.department;
  }

  updemp(updata) {
    this.service.update(updata);
  }

  delete(i) {
    this.service.delete(i);
  }

}

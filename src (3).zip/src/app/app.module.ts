import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {FormsModule} from '@angular/forms';



import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SortedheaderComponent } from './sortedheader/sortedheader.component';

@NgModule({
  declarations: [
    AppComponent,
    SortedheaderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [SortedheaderComponent]
})
export class AppModule { }
